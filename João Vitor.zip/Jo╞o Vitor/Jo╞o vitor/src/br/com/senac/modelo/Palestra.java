package br.com.senac.modelo;

public class Palestra {

	private String nomeDaSala;
	private String horario; // formato hh:mm
	private String titulo;
	private String resumo;
	
	private Palestrante palestrante;

	public String getNomeDaSala() {
		return nomeDaSala;
	}

	public void setNomeDaSala(String nomeDaSala) {
		this.nomeDaSala = nomeDaSala;
	}

	public String getHorario() {
		return horario;
	}

	public void setHorario(String horario) {
		this.horario = horario;
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public String getResumo() {
		return resumo;
	}

	public void setResumo(String resumo) {
		this.resumo = resumo;
	}

	public Palestrante getPalestrante() {
		return palestrante;
	}

	public void setPalestrante(Palestrante palestrante) {
		this.palestrante = palestrante;
	}

	@Override
	public String toString() {
		return "Palestra [nomeDaSala=" + nomeDaSala + ", horario=" + horario + ", titulo=" + titulo + ", resumo="
				+ resumo + ", palestrante=" + palestrante + "]";
	}
}
