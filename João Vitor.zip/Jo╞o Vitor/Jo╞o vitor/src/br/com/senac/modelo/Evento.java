package br.com.senac.modelo;

import java.time.LocalDateTime;
import java.util.ArrayList;

public class Evento {

	private String nomeInstituicao;
	private LocalDateTime dataEvento;
	private String nome;

	private ArrayList<Palestra> palestras = new ArrayList<>();

	private ArrayList<Participante> participantes = new ArrayList<>();

	private ArrayList<Organizador> organizadores = new ArrayList<>();

	public Evento() {
	}

	public String getNomeInstituicao() {
		return nomeInstituicao;
	}

	public void setNomeInstituicao(String nomeInstituicao) {
		this.nomeInstituicao = nomeInstituicao;
	}

	public LocalDateTime getDataEvento() {
		return dataEvento;
	}

	public void setDataEvento(LocalDateTime dataEvento) {
		this.dataEvento = dataEvento;
	}

	public ArrayList<Palestra> getPalestras() {
		return palestras;
	}

	public void setPalestras(ArrayList<Palestra> palestras) {
		this.palestras = palestras;
	}

	public ArrayList<Participante> getParticipantes() {
		return participantes;
	}

	public void setParticipantes(ArrayList<Participante> participantes) {
		this.participantes = participantes;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public ArrayList<Organizador> getOrganizadores() {
		return organizadores;
	}

	public void setOrganizadores(ArrayList<Organizador> organizadores) {
		this.organizadores = organizadores;
	}

	@Override
	public String toString() {
		return "Evento [nomeInstituicao=" + nomeInstituicao + ", dataEvento=" + dataEvento + ", nome=" + nome
				+ ", palestras=" + palestras + ", participantes=" + participantes + "]";
	}
}
