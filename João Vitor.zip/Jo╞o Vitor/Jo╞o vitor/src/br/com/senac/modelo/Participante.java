package br.com.senac.modelo;

public class Participante extends Pessoa {

	

}
