package br.com.senac.modelo;

public class Organizador extends Pessoa{
	
	

}
