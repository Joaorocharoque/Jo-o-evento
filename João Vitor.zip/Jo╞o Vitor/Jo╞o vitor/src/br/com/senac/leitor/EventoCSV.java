package br.com.senac.leitor;

import java.io.File;
import java.io.FileNotFoundException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Scanner;

import br.com.senac.modelo.Evento;

public class EventoCSV {

	public ArrayList<Evento> lerArquivo() {
		ArrayList<Evento> eventos = new ArrayList<>();
		Scanner sc;
		
		try {
			sc = new Scanner(new File("eventos.csv"));
			sc.useDelimiter("[,\n]");

		} catch (FileNotFoundException e) {
			System.out.println("Arquivo não encontrado.");
			return eventos;
		}

		boolean ehPrimeiraLinha = true;

		while (sc.hasNext()) {
			if (ehPrimeiraLinha) {
				sc.next();
				sc.next();
				sc.next();
				
				ehPrimeiraLinha = false;
				
			} else {
				Evento e = criaEvento(sc);
				
				eventos.add(e);
			}
		}
		
		sc.close();
		
		return eventos;
	}

	private Evento criaEvento(Scanner sc) {
		Evento evento = new Evento();
		evento.setNome(sc.next());
		evento.setNomeInstituicao(sc.next());
		
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
		LocalDateTime date = LocalDateTime.parse(sc.next(), formatter);
		
		evento.setDataEvento(date);
		return evento;
	}
}
