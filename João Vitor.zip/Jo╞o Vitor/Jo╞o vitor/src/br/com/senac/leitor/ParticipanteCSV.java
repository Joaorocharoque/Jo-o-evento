package br.com.senac.leitor;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

import br.com.senac.modelo.Evento;
import br.com.senac.modelo.Participante;

public class ParticipanteCSV {
	public ArrayList<Participante> lerArquivo(ArrayList<Evento> eventos) {
		ArrayList<Participante> participantes = new ArrayList<>();
		Scanner sc;
		
		try {
			sc = new Scanner(new File("participantes.csv"));
			sc.useDelimiter("[,\n]");

		} catch (FileNotFoundException e) {
			System.out.println("Arquivo não encontrado.");
			return participantes;
		}

		boolean ehPrimeiraLinha = true;

		while (sc.hasNext()) {
			if (ehPrimeiraLinha) {
				
				criaParticipante(sc, eventos);
				
				ehPrimeiraLinha = false;
				
			} else {
				Participante p = criaParticipante(sc, eventos);
				
				participantes.add(p);
			}
		}
		
		sc.close();
		
		return participantes;
	}

	private Participante criaParticipante(Scanner sc, ArrayList<Evento> eventos) {
		Participante participante = new Participante();
		participante.setNome(sc.next());
		participante.setEmail(sc.next());
		
		String nomeEvento = sc.next();
		
		for (Evento evento : eventos) {
			if(nomeEvento.equals(evento.getNome())) {
				evento.getParticipantes().add(participante);
			}
		}
		
		return participante;
	}
}

